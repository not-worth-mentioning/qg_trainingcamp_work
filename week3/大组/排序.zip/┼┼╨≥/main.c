#include "header.h"



int main() 
{
	int sizes1[]={10000, 50000,200000};  
    int sizes2[]={100000,200000,500000};
	  
    
	int i=0;
	printf("insert_sort:\n");  
    for (i=0;i<3;i++) 
	{  
        test_sort1(insert_sort,sizes1[i]);  
    }
    printf("quick_sort:\n");
    for (i=0;i<3;i++) 
	{  
        test_sort2(quick_sort,sizes1[i]);  
    }
    printf("merge_sort:\n");
	for (i=0;i<3;i++) 
	{  
        test_sort2(merge_sort,sizes2[i]);  
    }
    printf("counting_sort:\n");
    for (i=0;i<3;i++) 
	{  
        test_sort3(counting_sort,sizes2[i]);  
    }
    printf("radix_sort:\n");
	for (i=0;i<3;i++) 
	{  
        test_sort1(radix_sort, sizes2[i]);  
    }
	  
	return 0;
}
