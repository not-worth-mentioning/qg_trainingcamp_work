#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define BASE 10


void menu();
void insert_sort(int a[],int n);
int partition(int a[],int m,int n);
void quick_sort(int a[],int m,int n);
void merge_sort(int a[],int m,int n);
void merge(int a[], int m, int mid, int n);
void counting_sort(int *ini_a, int *sorted_a, int n);
void radix_sort(int *a, int n);
void random_data(int *arr, int size);
void test_sort1 (void (*sort_func)(int *, int), int size);
void test_sort2 (void (*sort_func)(int *,int,int), int size);
void test_sort3 (void (*sort_func)(int *, int* ,int ), int size);
