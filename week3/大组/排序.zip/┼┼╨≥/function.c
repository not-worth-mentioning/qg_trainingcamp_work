#include "header.h"




void insert_sort(int a[],int n)
{
	int i=0;
	for(i=1;i<n;i++)
	{
		int value=a[i];
		int j;
		for(j=i;j>0&&value<a[j-1];j--)
		{
			a[j]=a[j-1];
		}
		a[j]=value;
	}
}


int partition(int a[], int m, int n) {  
    int pivot=a[n];   
    int i=m-1;   
    int j=0;
    for (j=m;j<n;j++) 
	{  
        if (a[j]<=pivot) 
		{   
            i++;   
            int temp=a[i];  
            a[i]=a[j];  
            a[j]=temp;  
        }  
    }  
      
    int temp=a[i+1];  
    a[i+1]=a[n];  
    a[n]=temp;  
  
    return i + 1;   
}

void quick_sort(int a[],int m,int n)
{
	if(m<n)
	{
		int mid=partition(a,m,n);
		quick_sort(a,m,mid-1);
		quick_sort(a,mid+1,n);
	}
	
}


void merge(int a[], int m, int mid, int n) 
{   int i;
    int j;
    int k;
    int left=mid-m+1;  
    int right=n-mid;  
    
    int temp[right];  
    for (j=0;j<right;j++) {  
        temp[j]=a[mid+1+j];  
    }  
  
    i=m;   
    j=0;  
    k=m;   
    while (i<=mid&&j<right) 
	{  
        if (a[i] <= temp[j]) 
		{  
            a[k]=a[i++];       
        } 
		else 
		{  
            a[k]=temp[j++];       
        }  
        k++;  
    }   
    while (i<=mid) 
	{  
        a[k++]=a[i++];     
    }   
    while (j<right) 
	{  
        a[k++] = temp[j++];  
    }  
}  
  
void merge_sort(int a[], int m, int n) {  
    if(m==n)return;
	if(m<n) 
	{  
        int mid=(m + n)/2;  
        merge_sort(a,m,mid);  
        merge_sort(a,mid+1,n);    
        merge(a,m,mid,n);  
    }  
}


void counting_sort(int *ini_a, int *sorted_a, int n) 
{  
    int *b = (int *)malloc(sizeof(int) *1000000);   
    int i, k;  
    for(k=0;k<100;++k) 
	{  
        b[k]=0;  
    }  
    for (i=0;i<n;++i) 
	{  
        b[ini_a[i]]++;  
    }  
      
    for(k=1;k<100;++k) 
	{  
        b[k]+=b[k-1];  
    }  
      
    for (i=n-1;i>= 0;--i) 
	{  
        sorted_a[b[ini_a[i]]-1]=ini_a[i];  
        b[ini_a[i]]--;  
    }  
      
    free(b);  
}



void radix_sort(int *a, int n) 
{
  int i,b[1000000],m=a[0],exp=1;

  for (i=1;i<n; i++) 
  {
    if (a[i]>m) 
	{
      m=a[i];
    }
  }

  while (m/exp > 0) {
    int bucket[BASE] = {0};

    for (i=0;i<n; i++) 
	{
      bucket[(a[i]/exp) % BASE]++;
    }

    for (i = 1;i<BASE;i++) 
	{
      bucket[i]+=bucket[i - 1];
    }

    for (i=n-1;i>=0;i--) 
	{
      b[--bucket[(a[i]/exp)%BASE]]=a[i];
    }

    for (i=0;i<n;i++) {
      a[i]=b[i];
    }

    exp *= BASE;
}
}

void random_data(int *arr, int size) 
{  
    srand(time(NULL));
	int i=0;   
    for (i=0;i<size;i++) 
	{  
        arr[i]=rand()%10000;  
    }  
}

void test_sort1 (void (*sort_func)(int *, int), int size) 
{  
    int *arr=(int *)malloc(size * sizeof(int));  
    
  
    random_data(arr, size);  
  
    clock_t start_time=clock();  
    sort_func(arr,size);  
    clock_t end_time=clock();  
  
    double elapsed_time = (double)(end_time - start_time)/CLOCKS_PER_SEC;  
    printf("Sorting %d elements took %f seconds.\n", size, elapsed_time);  
  
    free(arr);
	   
}    


void test_sort2 (void (*sort_func)(int *, int ,int ), int size) 
{  
    int *arr=(int *)malloc(size * sizeof(int));  
    
  
    random_data(arr, size);  
  
    clock_t start_time=clock();  
    sort_func(arr,0,size);  
    clock_t end_time=clock();  
  
    double elapsed_time=(double)(end_time - start_time) / CLOCKS_PER_SEC;  
    printf("Sorting %d elements took %f seconds.\n", size, elapsed_time);  
  
    free(arr);
	   
}  

void test_sort3 (void (*sort_func)(int *, int* ,int ), int size) 
{  
    int *arr=(int *)malloc(size * sizeof(int));  
    int *b=(int *)malloc(size * sizeof(int));
  
    random_data(arr, size);  
  
    clock_t start_time = clock();  
    sort_func(arr,b,size);  
    clock_t end_time = clock();  
  
    double elapsed_time = (double)(end_time - start_time);  
    printf("Sorting %d elements took %f seconds.\n", size, elapsed_time);  
  
    free(arr);
    free(b);
	   
}    



