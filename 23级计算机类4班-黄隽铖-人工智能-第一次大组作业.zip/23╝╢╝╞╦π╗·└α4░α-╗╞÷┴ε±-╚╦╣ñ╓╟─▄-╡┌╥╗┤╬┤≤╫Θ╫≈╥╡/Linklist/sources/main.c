#include "head.h"

int main() {
	
	v: ;LNode* head;
	head=Init_Linklist();
	DNode* lead;
	lead=Init_DLinklist();
	
    m:	menu();
    printf("��ѡ������:");
	int number=0;
	scanf("%d",&number);
	switch(number)
	{
		case 1:
		    Create_Linklist(head);
		    printf("��ʼ���ɹ�\n");
		       
			system("pause");
			system("cls");
			goto m;
		
		case 2:;
			int y=0;
			y=Print_Linklist(head);
			if(y)printf("��ӡ�ɹ�\n");
			
			system("pause");
			system("cls");
			goto m;
			
		case 3:
			Insert_Linklist(head);
			
			
			system("pause");
			system("cls");
			goto m;
			
		case 4:
			Find_Linklist(head);
			
			system("pause");
			system("cls");
			goto m;
		
		case 5:
			Delete_Linklist(head);
			
			system("pause");
			system("cls");
			goto m;
			
		case 6:
			Destroy_Linklist(head);
			
			system("pause");
			system("cls");
			goto v;
			
		case 7:
			Swap_Linklist(head);
			
			system("pause");
			system("cls");
			goto m;
			
		case 8:
			Find_middle_element(head);
			
			system("pause");
			system("cls");
			goto m;
			
		case 9:;
			int c=0;
	        c=Loop_Linklist(head);  
	 		if(c==1)printf("�����ǻ�״\n");
			else printf("�������ǻ�״\n");
			
			system("pause");
			system("cls");
			goto m;
			
		case 10:
			Reverse_Linklist(head);
			
			system("pause");
			system("cls");
			goto m;
			
		case 11:
			Create_DLinklist(lead);
			printf("��ʼ���ɹ�\n");
			
			system("pause");
			system("cls");
			goto m;
			
		case 12:;
		    int z=0;
			z=Print_DLinklist(lead);
			if(z)printf("��ӡ�ɹ�\n");
			
			system("pause");
			system("cls");
			goto m;
			
		case 13:
			Insert_DLinklist(lead);
			
			system("pause");
			system("cls");
			goto m;
			
		case 14:
			Delete_DLinklist(lead);
			
			system("pause");
			system("cls");
			goto m;
		
		case 15:
			Destroy_DLinklist(lead);
			
			system("pause");
			system("cls");
			goto v;
			
		case 16:
			exit(0);	
	}
	 

	return 0;
}
